# Collaborators: Aadem Isai, Jenna Hopkins 

class Dancer:
    def __init__(self, emoji):
        self._emoji = emoji
    
    def emoji(self):
        return self._emoji
    
    def __repr__(self):
        return str(self._emoji)
    
    def __str__(self):
        return str(self._emoji)