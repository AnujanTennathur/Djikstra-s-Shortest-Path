
Dance Off is a game designed to generate different dancers and dance sequences. The number of dancers, their respective emojis, and the number of different dances, are set in place. However, the number of dance rounds is user controlled, and the amount of times the user wants to play the game is also user controlled. 

For my code, the theme is sports. As seen below, the dancers are: basketball, football, hockey, soccer, baseball, golf, and volleyball. Similarly, my dances (also shown below), are based on different actions within those sports, and are the following: Slam Dunk, Hole in One, Kill, Touchdown, Goal, Home Run. 

Your Dancers are Ready!
🏀 🏈 🏒 ⚽ ⚾ ⛳ 🏐 

The text above shows the initial configuration of the different dancers, and their respective emojis. The dances that the above dancers complete vary depending on the dance move. Here are the names of the dances and what they do: 

1: Slam Dunk - the new dancer becomes the first dancer in the line.
ex: 
2: Hole in One -  the new dancer becomes the last dancer in the line.
3: Kill -  the new dancer joins the line at a random position X, where X <= length of the line.
4: Touchdown - remove the first matching dancer from the line and then add the new dancer to the end of the line.
5: Goal -  take the new dancer and generate two more matching dancers. Place one dancer at the front of the line, one dancer in the middle of the line, and the other dancer at the end of the line.
6: Home Run - Add the dancer to the front of the line, then add one of each dancer type to the end of the line.

To play the game, the user is initially prompted to enter the number of rounds they want to play. After the number of rounds of dances are completed, the user is told that the dance off is over, and is then prompted to either end the game, or to keep playing. If the user chooses to keep playing, the game repeats after the user enters the number of rounds. If the user chooses to end the game, then the game quits. 

That is the summary of Dance Off. Hope you have fun playing! 