

from Projects.evolutionofdance.program import DanceOff


def main():
    evolutionOfDance = DanceOff()
    evolutionOfDance.setup()


if __name__ == "__main__":
    main()