# Collaborators: Aadem Isai, Jenna Hopkins 

import random
from datastructures.array import Array
from datastructures.linked_list import LinkedList
from Projects.evolutionofdance.Dancers import Dancer

class DanceOff:
    def __init__(self):
        self._dancers = Array.from_list([Dancer("🏀"), Dancer("🏈"), Dancer("🏒"), Dancer("⚽"), Dancer("⚾"), Dancer("⛳"), Dancer("🏐")])
        self._dance_names = Array.from_list(["Slam Dunk", "Hole in One", "Kill", "Touchdown", "Goal", "Home Run"]) 
        self._dance_line = LinkedList.from_list([Dancer("🏀"), Dancer("🏈"), Dancer("🏒"), Dancer("⚽"), Dancer("⚾"), Dancer("⛳"), Dancer("🏐")])

    def setup(self) -> None:
        """
        Starts the game by asking how many rounds to play and calling the play_game function

        Returns:
            None
        """
        print("Welcome to Dance Off!")
        not_decided = True
        while not_decided:
            rounds = int(input("How many rounds would you like to play? "))
            if isinstance(rounds, int):
                not_decided = False
            else:
                print("Please enter a number.  No decimals please 😩. ")
        self.play_game(rounds)
        return None

    def play_game(self, rounds: int) -> None:
        """
        Plays the game by calculating the board after the amount of rounds the user specifies, 
        and then determines if it should play again

        Args:
            rounds (int): the number of rounds the user would like to play

        Returns:
            None
        """
        self._dance_line = LinkedList.from_list([Dancer("🏀"), Dancer("🏈"), Dancer("🏒"), Dancer("⚽"), Dancer("⚾"), Dancer("⛳"), Dancer("🏐")])
        print("LETS DANCE!!!")
        print(f"Dance Line: {self._dance_line}")
        for i in range(rounds):
            print(f"Round {i + 1}:")
            self.new_round()
            print(self._dance_line)
            if (i + 1) % 5 == 0:
                print("Removing first and last dancers in the line!:")
                self._dance_line.pop_front()
                self._dance_line.pop_back()
                print(self._dance_line)
        print("Dance-Off is Over!")
        decided = False
        while not decided:
            try:
                rounds = int(input("Play again? Enter the number of rounds. Click 0 to quit. "))
                decided = True
            except ValueError:
                print("Please enter an integer value.")
        if rounds != 0:
            self.play_game(rounds)
        else: 
            print("Hope you had fun playing Dance Off!!")
        

    def new_round(self) -> None:
        """
        Randomly chooses a new dancer and dance and determines what happens to the dance line based on the dance

        Returns: 
            None
        """
        new_dancer_index = random.randint(0, 6)
        new_dance = random.randint(1, 6)
        print(f"{self._dancers[new_dancer_index].emoji()} has joined and is starting the {self._dance_names[new_dance - 1]}!")
        match new_dance:
            case 1: # adds dancer to the front of the line
                self._dance_line.prepend(self._dancers[new_dancer_index])
            case 2: # adds dancer to the end of the line
                self._dance_line.append(self._dancers[new_dancer_index])
            case 3: # adds dancer to a random position in the line
                self.third_dance(new_dancer_index)
            case 4: # removes dancer from the dance line in the first instance it appears and adds it to the end
                self.fourth_dance(new_dancer_index)
            case 5: # adds dancer to the front, end, and middle of the line
                self.fifth_dance(new_dancer_index)
            case 6: # adds dancer to the front of the line and every dancer is added to the end of the line
                self.sixth_dance(new_dancer_index)
        return None

    def third_dance(self, new_dancer_index: int) -> None:
        """
        Adds the dancer to a random position in the line

        Args:
            new_dancer_index (int): the index of the new dancer to be used in the unicode array

        Returns:
            None
        """
        if len(self._dance_line) == 0:
            self._dance_line.append(self._dancers[new_dancer_index])
        elif len(self._dance_line) == 1:
            position = random.randint(0, 1)
            if position == 0:
                self._dance_line.prepend(self._dancers[new_dancer_index])
            else:
                self._dance_line.append(self._dancers[new_dancer_index])
        else:
            after_element = None
            target_index = random.randint(0, len(self._dance_line) - 1)
            index = 0
            for item in self._dance_line:
                if index == target_index - 1:
                    after_element = item
                    break
                else:
                    index += 1
            if after_element == None:
                after_element = self._dance_line.back
            self._dance_line.insert_after(after_element, self._dancers[new_dancer_index])
        return None

    def fourth_dance(self, new_dancer_index: int) -> None:
        """
        Removes the dancer from the dance line in the first instance it appears and adds it to the end.
        If the dancer is not in the line, it just adds it to the end.

        Args:
            new_dancer_index (int): the index of the new dancer to be used in the unicode array

        Returns:
            None
        """
        try:
            self._dance_line.extract(self._dancers[new_dancer_index])
            self._dance_line.append(self._dancers[new_dancer_index])
        except KeyError:
            self._dance_line.append(self._dancers[new_dancer_index])
        return None

    def fifth_dance(self, new_dancer_index: int) -> None:
        """
        Adds the dancer to the front, end, and middle of the line

        Args:
            new_dancer_index (int): the index of the new dancer to be used in the unicode array

        Returns:
            None
        """
        self._dance_line.prepend(self._dancers[new_dancer_index])
        self._dance_line.append(self._dancers[new_dancer_index])
        target_index = len(self._dance_line) // 2
        index = 0
        after_element = None
        for item in self._dance_line:
            if index == target_index - 1:
                after_element = item
                break
            else:
                index += 1
        if after_element == None:
            after_element = self._dance_line.back
        self._dance_line.insert_after(after_element, self._dancers[new_dancer_index])
        return None

    def sixth_dance(self, new_dancer_index: int) -> None:
        """
        Adds the dancer to the front of the line and every dancer is added to the end of the line

        Args:
            new_dancer_index (int): the index of the new dancer to be used in the unicode array

        Returns:
            None
        """
        self._dance_line.prepend(self._dancers[new_dancer_index])
        for item in self._dancers:
            self._dance_line.append(item)
        return None