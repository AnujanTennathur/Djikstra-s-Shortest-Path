![Starting Image](Screenshot_Image_1.png)
![End Image](End_Screenshot.png)

The game of life is a simulation that is based on rules about cells in a grid. The cells are represented by either a "-" or an "X", with the "X" represents an alive cell, with a "-" representing a dead cell. 

To simplify this rules down, there are 4 main concepts: 
Birth, Survival, Death by underpopulation, and Death by overpopulation

The Rules of the game in more detail are provied below. Again, the simulation is based on the 
main concepts above, and rules below follow this pattern: 
- A location that has zero or one neighbors will be empty in the next. If a cell was in that location, it dies of loneliness.
- A location with two neighbors is stable—that is, if it contained a cell, it still contains a cell. If it was empty, it's still empty.
- A location with three neighbors will contain a cell in the next generation. If it was unoccupied before, a new cell is If it currently contains a cell, the cell remains. Good times.
- A location with four or more neighbors will be empty in the next If there was a cell in that location, it dies of overcrowding.
- The births and deaths that transform one generation to the next must all take effect simultaneously. Thus, when computing a new generation, new births and deaths in that generation don’t impact other births and deaths in that to keep the two generations, separate, you will need to work on two versions of the grid—one for the current generation, and a second that allows you to compute and store the next generation without changing the current one.

To play the simulation, the user has the initial option to seed the grid of the game either randomly or manually. If you seed the game randomly, then the simulation produces a random starting configuration. If manually, it uses the starting configuration in the starting screenshot that the user can change. 

Secondly, the user can choose the speed of the game, between fast, medium, slow, and manual. In the manual setting, the user has to keep clicking the return/enter button to create new simulations. 

For the end game, the game ends when colony becomes completely stable, or if the user chooses to leave the game. To clarify, if the colony has evolved to a configuration that has no changes between generations, the simulation.