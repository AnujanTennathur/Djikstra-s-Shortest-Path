# Collaborator: Aadem 

from typing import Any
from random import random, randint, randrange
from datastructures.array2d import Array2D
from Projects.gameoflife.kbhit import KBHit
from time import sleep
import time


def count_neighbors(grid, x, y):
    """
    Counts the number of live neighbors around a cell at the 
    provided position with the coordinates (x, y) in the grid.

    Args:
    grid (Array2D): The grid for the game of life.
    x (int): The x-coordinate of the specific cell.
    y (int): The y-coordinate of the specific cell.

    Returns:
    int: The count of live neighbors.
    """
    rows, columns = grid.dimensions
    count = 0
    for i in range(-1, 2): 
        for j in range(-1, 2): 
            if not (i == 0 and j == 0):
                neighbor_x = x + i
                neighbor_y = y + j
                if 0 <= neighbor_x < rows and 0 <= neighbor_y < columns:
                    if grid[neighbor_x][neighbor_y] == "X":
                        count += 1
    return count
    
def apply_rules(grid):
    """
    Applies the rules of the "game of life" to generate the next generation.

    Args:
    grid (Array2D): The current generation grid.

    Returns:
    Array2D: The grid for the next generation.
    """

    rows, columns = grid.dimensions
    next_generation = Array2D(rows, columns, "-")

    for i in range(rows):
        for j in range(columns):
            live_neighbors = count_neighbors(grid, i, j)

            if grid[i][j] == "X":
                if live_neighbors < 2 or live_neighbors > 3:
                    next_generation[i][j] = "-"  
                else:
                    next_generation[i][j] = "X" 
            else:
                if live_neighbors == 3:
                    next_generation[i][j] = "X" 
                else:
                    next_generation[i][j] = "-"
    return next_generation


def read_grid_from_file(filename):
    """
    Reads the grid configuration from the gridConfiguration text
    file, and converts it into an Array2D.

    Args:
    filename (str): name of the file containing the grid configuration.

    Returns:
    Array2D: The grid configuration read from the file.
    """
    with open(filename) as f:  
        grid = []
        for line in f:
            stripped_line = line.strip()
            row = []
            for cell in stripped_line:
                if cell == "X":
                    row.append(cell)
                else:
                    row.append("-")
            grid.append(row)
        manual_grid = Array2D.from_list(grid)
    return manual_grid
    
def main_gameplay():
    """
    The Main gameplay function for the game of life game. 
    Args and Returns: N/A
    """
    rows = 20
    columns = 20
    living_cell = ""
    generation = 0
    grid = Array2D(rows, columns)
    option = input("Do you want to seed the grid randomly? (yes/no): ")
    if option.lower() == "yes":
        for i in range(rows):
            for j in range(columns):
                grid[i][j] = (randint(0, 1))
                if grid[i][j] == 1:
                    grid[i][j] = "X"
                else:
                    grid[i][j] = "-"
        print(f"Generation: {generation}")
        print(grid)
    elif option.lower() == "no":
        filename = "Projects/gameoflife/gridConfiguration.txt" 
        grid = read_grid_from_file(filename)  
        print(f"Generation: {generation}")
        print(grid)
    else:
        print("Invalid option. Defaulting to random seeding.")
        for i in range(rows):
            for j in range(columns):
                grid[i][j] = (randint(0, 1))
                if grid[i][j] == 1:
                    grid[i][j] = "X"
                else:
                    grid[i][j] = "-"
        print(f"Generation: {generation}")
        print(grid)
    
    interval = 0
    option_speed = input("What speed would you like (Slow/Medium/Fast)?: ")
    if option_speed.lower() == "fast":
        interval = 0
        print("When you feel done, press 'Backspace' to quit!")
    elif option_speed.lower() == "slow":
        interval = 8
        print("When you feel done, press 'Backspace' to quit!")
    elif option_speed.lower() == "medium":
        interval = 5
        print("When you feel done, press 'Backspace' to quit!")
    elif option_speed.lower() == "manual":
        print("Press enter to start! Or press 'Backspace' to quit!")
        interval = 5
    else:
        print("Invalid option. Defaulting to Manual Speed")
        print("Press enter to start! Or press 'Backspace' to quit!")
        interval = 5

    kb = KBHit()
    stable = False
    prev_grids = [] 
    while not stable:
        grid = apply_rules(grid)
        if grid in prev_grids:
            print("The grid has stabilized.")
            kb.set_normal_term()
            stable = True
            play_again()
            break
        prev_grids.append(grid)
        if option_speed.lower() == "manual" or option_speed.lower() not in ["fast", "medium", "slow"]:
            kb.kbhit()
            c = kb.getch()
            if ord(c) == 127:  
                kb.set_normal_term()
                stable = True
                play_again()
                kb = KBHit()
            elif ord(c) == 10:  
                if stable == False:
                    print(f"Generation: {generation + 1}")
                    print(grid)
                    generation += 1
                    continue  
            elif ord(c) == 27:
                break
        else:
            print(f"Generation: {generation + 1}")
            print(grid)
            time.sleep(interval)
            generation += 1

def play_again(): 
    """
    Asks the user if they want to play the game again or exit.
    Args and Returns: N/A
    """
    completed = False
    while not completed:   
        play_choice = input("Game over! Would you like to play again? ")
        if play_choice.lower() == "yes":
            main_gameplay()
            completed = True
        elif play_choice.lower() == "no":
            print("Thank you for playing Game of Life!")
            completed = True
        else:
            print("Thanks for playing!")
            completed = True
            


if __name__ == "__main__":
    main_gameplay()

