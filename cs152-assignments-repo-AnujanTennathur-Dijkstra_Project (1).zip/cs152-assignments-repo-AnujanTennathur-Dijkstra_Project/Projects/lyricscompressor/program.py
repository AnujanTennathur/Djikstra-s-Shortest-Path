
from datastructures.hash_map import HashMap


class FileUtils(): 
    @staticmethod
    def read_file(filename: str):
        lines = []
        with open(filename, 'r') as file:
            lines = file.readlines()
        
        return lines
    
    @staticmethod
    def write(filename: str, content: str):
         with open(filename, 'w') as file:
            file.write(content)
        

class Compressor():
    def __init__(self, file_utils: FileUtils):
        self.compress_text = HashMap()
        self.file_utils = FileUtils()

    def compress(self, filename: str):
        lines = self.file_utils.read_file(filename)
        word_indexes = []
        position = 0
        for line in lines:
            for i, word in enumerate(line.split()):
                if i == len(line.split()) - 1:
                    position = position * -1
                if word not in self.compress_text:
                    word_indexes = [position]
                else: 
                    word_indexes = self.compress_text[word]
                    word_indexes.append(position)
                self.compress_text[word] = word_indexes
                if position < 0: 
                    position = position * -1
                position += 1
    
    def decompress(self, filename: str):
        pass
   
    def debug_map(self):
        print(self.compress_text)
   
    def run(self): 
        selection = input("Enter 1 to compress, 2 to decompress, 3 to debug map, 4 to exit: ")

        while selection != "4":
            match selection: 
                case "1":
                    filename = input("Enter the name of the file to compress: ")
                    filename = f"Projects/lyricscompressor/{filename}"
                    self.compress(filename)
                case "2":
                    filename = input("Enter the name of the file to compress: ")
                    filename = input("Enter the name of the file to compress: ")
                    self.decompress(filename)
                case "3":
                    self.debug_map()
                case "4":
                    return
                case _:
                    print("Invalid selection. Please try again.")
                    self.run()
            selection = input("Enter 1 to compress, 2 to decompress, 3 to debug map, 4 to exit: ")
def main():
    compressor = Compressor(FileUtils)

    compressor.run()

if __name__ == '__main__':
    main()
