# datastructures.array2d.Array2D

""" This module defines an Array2D class that represents a two-dimensional array. 
    The Array class uses a datastructures.Array object as the internal data structure. 
    The Array class adheres to the docstring requirements per method, including raising 
    appropriate exceptions where indicated.
"""

# Collaborator: Aadem Isai

from typing import Any

from datastructures.array import Array


class Array2D:
    """ Class Array2D - representing 2D data using a 1D Array
            Stipulations:
            1. Must use an Array object as the internal data 
                structure from the Array assignment.
            2. Must adhere to the docstring requirements per method, 
                including raising raising appropriate exceptions where indicated.
    """

    def __init__(self, rows: int = 0, columns: int = 0, default_item_value = None) -> None:
        """ Array2D Constructor. Initializes the Array2D with the desired size and default value.
            
        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(array2d)
            [[None, None, None], [None, None, None]]

        Args:
            rows (int): the desired number of rows.
            columns (int): the desired number of columns.
            default_item_value (Any): the default value to initialize the Array2D items with.
        
        Returns:
            None
        """

        # Formula: map_index: row_index * column_len + column_index
        # create new function inside class item with formula and then pass into get and set functions
        if rows < 0 or columns < 0:
            raise ValueError("Number of rows and columns can't be a negative number.")
        
        self._rows = rows
        self._columns = columns
        self._items2d = Array(size=rows*columns, default_item_value=default_item_value)
    
    class _Row: 
        def __init__(self, items: Array, columns: int, row_index):
            self._items = items
            self._columns = columns
            self._row_index = row_index
        
        def map_to_1d(self, column_index: int) -> int:
            return self._row_index * self._columns + column_index
        
        def __getitem__(self, column_index: int) -> Any:
            return self._items[self.map_to_1d(column_index)]
        
        def __setitem__(self, column_index: int, data: Any) -> None:
            self._items[self.map_to_1d(column_index)] = data

    def __getitem__(self, row_index: int) -> Any:
        """ Bracket operator for accessing an item. This bracket operator is used to 
            access the first dimension (row). This should return an object that allows
            the bracket operator to be used again to access the second dimension (column).
        
        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d[0][0] = 1
            >>> print(array2d[0][0])
            1
        """
        # row, column = 1, 1
        # array2d[row][column]

        return self._Row(self._items2d, self._columns, row_index)
    
    @property
    def dimensions(self):
        """ Property for getting dimensions of the Array2D.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(array2d.dimensions)
            (2, 3)
            >>> rows, columns = array2d.dimensions
            >>> print(rows)
            2
            >>> print(columns)
            3
        """
        return self._rows, self._columns

    def resize_columns(self, new_columns_len: int, default_item_value: Any = None) -> None:
        """ Resize the length of the columns. Must be able to handle both increasing and 
            decreasing the size of the columns. Must not lose any data when resizing
            the columns. If the new length is smaller, then the data will be truncated.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d.resize_columns(4)
            >>> print(array2d.dimensions)
            (2, 4)
            >>> array2d.resize_columns(2)
            >>> print(array2d.dimensions)
            (2, 2)
        """

        if new_columns_len < 0:
            raise ValueError("Number of columns must be non-negative.")

        if new_columns_len == self._columns:
            return ("No need to resize if the number of columns is unchanged")

        new_items = Array(size = self._rows * new_columns_len, default_item_value = default_item_value)

        for row in range(self._rows):
            for col in range(min(self._columns, new_columns_len)):
                new_items[row * new_columns_len + col] = self._items2d[row * self._columns + col]
        
        if new_columns_len > self._columns:
            for col in range(self._columns, new_columns_len):
                new_items[row * new_columns_len + col] = default_item_value
        

        self._columns = new_columns_len
        self._items2d = new_items

    def resize_rows(self, new_rows_len: int, default_item_value: Any = None) -> None:
        """ Resize the length of the rows. Must be able to handle both increasing and
            decreasing the size of the rows. Must not lose any data when resizing the rows.
            If the new length is smaller, then the data will be truncated.
            
        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d.resize_rows(4)
            >>> print(array2d.dimensions)
            (4, 3)
            >>> array2d.resize_rows(2)
            >>> print(array2d.dimensions)
            (2, 3)
        """
        new_items = Array(size = self._columns * new_rows_len, default_item_value = default_item_value)

        if new_rows_len==self._rows: 
            return ("Number of rows is the same, no need to resize.")
        
        if new_rows_len<0: 
            raise ValueError("Number of rows must be a positive number.")
        
        counter = 0
        for row in range(new_rows_len):
            for col in range(self._columns):
                if row >= self._rows:
                    new_items[counter] = default_item_value
                else:
                    new_items[counter] = self._items2d[counter]
                counter += 1

        self._items2d = new_items
        self._rows = new_rows_len
        self._default_item_value = default_item_value
        return None

    def __eq__(self, other: object) -> bool:
        """ Equality operator ==.

        Examples:
            >>> array2d1 = Array2D(rows=2, columns=3)
            >>> array2d2 = Array2D(rows=2, columns=3)
            >>> print(array2d1 == array2d2)
            True
            >>> array2d2[0][0] = 1
            >>> print(array2d1 == array2d2)
            False
        """
        if not isinstance(other, Array2D):
            return False
        if self._rows != other._rows or self._columns != other._columns:
            return False
        for i in range (self._rows):
            for j in range(self._columns):
                if self[i][j] != other[i][j]:
                    return False
        return True

    def __ne__(self, other: object) -> bool:
        """ Non-equality operator !=.
        
        Examples:
            >>> array2d1 = Array2D(rows=2, columns=3)
            >>> array2d2 = Array2D(rows=2, columns=3)
            >>> print(array2d1 != array2d2)
            False
            >>> array2d2[0][0] = 1
            >>> print(array2d1 != array2d2)
            True
        """
        if not isinstance(other, Array2D):
            return True
        if self._rows != other._rows or self._columns != other._columns:
            return True
        for i in range (self._rows):
            for j in range(self._columns):
                if self[i][j] != other[i][j]:
                    return True
        return False

    def __contains__(self, item: Any) -> bool:
        """ Contains operator (in).

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(3 in array2d)
            False
            >>> array2d[0][0] = 3
            >>> print(3 in array2d)
            True
        """
        for i in range(self._rows):
            for j in range(self._columns):
                if self[i][j] == item:
                    return True

    def __str__(self) -> str:
        """ Return a string representation of the data and structure

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(array2d)
            [[None, None, None], [None, None, None]]
        
        """
        rows = []
        for i in range(self._rows):
            row = []
            for j in range(self._columns):
                value = self._items2d[self._columns * i + j]
                if value is None:
                    row.append("None")
                else:
                    row.append(str(value))
            rows.append("[" + ", ".join(row) + "]")
        return "[" + ", ".join(rows) + "]"

    def __repr__(self) -> str:
        """ Return a string representation of the data and structure.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(repr(array2d))
            [[None, None, None], [None, None, None]]
        """
        rows = []
        for i in range(self._rows):
            row = []
            for j in range(self._columns):
                value = self._items2d[self._columns * i + j]
                if value is None:
                    row.append("None")
                else:
                    row.append(str(value))
            rows.append("[" + ", ".join(row) + "]")
        return "[" + ", ".join(rows) + "]"
    
    @staticmethod
    def from_list(items: list):
        """Create an Array2D from a 2D Python list."""
        if not isinstance(items, list):
            raise ValueError("Input must be a list")

        rows = len(items)
        if rows == 0:
            raise ValueError("Input list must not be empty")

        for row in items:
            if not isinstance(row, list):
                raise ValueError("Inner elements must be lists")
        
        columns = len(items[0])
        
        for row in items:
            if len(row) != columns:
                raise ValueError("Input list must be rectangular")

        array_2d = Array2D(rows, columns)
        
        for i in range(rows):
            for j in range(columns):
                array_2d[i][j] = items[i][j]

        return array_2d
    
    def clear(self) -> None:
        """ Clear operator. Clears the Array2D.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d.clear()
            >>> print(array2d)
            [[None, None, None], [None, None, None]]

        Returns:
            None
        """
        for i in range(self._rows):
            for j in range(self._columns):
                self[i][j] = None
    