# Collaborators: Aadem, Jenna 

from __future__ import annotations
from typing import Any

from datastructures.list_node import ListNode
import numpy as np

class LinkedList:
    """ Class LinkedList - representing an unordered linked list
        Depends on ListNode class to store the data, previous, and next nodes.
            Stipulations:
            1. Must manage the linked list using two ListNode objects (_head and _tail)
            2. Must adhere to the docstring requirements per method, including raising
               raising appropriate exceptions where indicated.
    """

    def __init__(self) -> None:
        """ Constructor for the LinkedList constructs an empty linked list.

        Examples:
            >>> linked_list = LinkedList()
            >>> print(linked_list)
            []
        
        Returns:
            None
        
        """
        self._head = None
        self._tail = None
        self._count = 0

    @staticmethod
    def from_list(py_list: list) -> LinkedList:
        """ Create a new LinkedList from a Python list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list)
            ['cat', 'dog', 'bird']
        
        Args:
            py_list (list): list to convert to a linked list.

        Returns:
            A new LinkedList instance.
        
        Raises:
            TypeError: if py_list is not a list.
        """
        if not isinstance(py_list, list):
            raise TypeError("The following py_list is not a list!")
        linked_list = LinkedList()
        for item in py_list:
            linked_list.append(item)

        return linked_list

    def append(self, item: Any) -> None:
        """ Append an item to the end of the list.

        Examples:
            >>> linked_list = LinkedList()
            >>> linked_list.append('cat')
            >>> linked_list.append('dog')
            >>> print(linked_list)
            ['cat', 'dog']
        
        Args:
            item: the desired data to append to the linked list.
        
        Returns:
            None
        """
        self._tail = ListNode(item, previous_node = self._tail)
        if self._head is None:
            self._head = self._tail
        else:
            if self._tail.previous is not None:
                self._tail.previous.next = self._tail

        self._count += 1

    def prepend(self, item: Any) -> None:
        """ Prepend an item to the beginning of the list.
        
        Examples:
            >>> linked_list = LinkedList()
            >>> linked_list.prepend('cat')
            >>> linked_list.prepend('dog')
            >>> print(linked_list)
            ['dog', 'cat']
        
        Args:
            item (Any): the desired data to prepend to the linked list.
            
        Returns:
            None
        
        """
        self._head = ListNode(item, next_node = self._head)
        if self._tail is None:
            self._tail = self._head
        else:
            if self._head.next is not None:
                self._head.next.previous = self._head

        self._count += 1

    def insert_before(self, before_item: Any, new_item: Any) -> None:
        """ Insert a new item before a specified item.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.insert_before('dog', 'fish')
            >>> print(linked_list)
            ['cat', 'fish', 'dog', 'bird']
                
        Args:
            before_item (Any): the item that the user wishes to insert before.
            new_item (Any): the desired item to insert.
        
        Returns:
            None
        
        Raises:
            KeyError: if before_item is not found.
        """
        current = self._head
        found = False
        while current is not None:
            if current == before_item:
                found = True
                new_node = ListNode(new_item, current.previous, current)
                if current.previous is not None:
                    current.previous.next = new_node
                current.previous = new_node
                if current == self._head:
                    self._head = new_node
                self._count += 1
                break
            current = current.next

        if not found:
            raise KeyError(f"{before_item} not found in the list")
        

    def insert_after(self, after_item: Any, new_item: Any) -> None:
        """ Insert a new item after a specified item.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.insert_after('dog', 'fish')
            >>> print(linked_list)
            ['cat', 'dog', 'fish', 'bird']

        Args:
            after_item (Any): the item that the user wishes to insert after.
            new_item (Any): the desired item to insert.

        Returns:
            None

        Raises:
            KeyError: if after_item is not found.
        
        """
        
        current = self._head
        if current is None:
            raise KeyError(f"{after_item} not found in the list")
        
        while current is not None:
            if str(current) == str(after_item):
                after_node = current.next
                new_node = ListNode(new_item, previous_node = current, next_node = after_node)
                if after_node is not None:
                    after_node.previous = new_node
                current.next = new_node
                self._count += 1
                return None
            current = current.next

        raise KeyError(f"{after_item} not found in the list")

    @property
    def head(self) -> ListNode | None:
        """ Return the ListNode instance pointing at the head of the linked list.
            Note: this method should be used for debug and test purposes only.
            
        Examples
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> head = linked_list.head
            >>> print(head.item)
            cat
        
        Returns:
            head (ListNode | None): the ListNode instance representing the head of the linked list.
            
        """
        return self._head

    @property
    def tail(self) -> ListNode | None:
        """ Return the ListNode instance pointing at the tail of the linked list.
            Note: this method should be used for debug and test purposes only.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> tail = linked_list.tail
            >>> print(tail.item)
            bird
        
        Returns:
            tail (ListNode | None): the ListNode instance representing the tail of the linked list.
        """
        return self._tail

    @property
    def front(self) -> Any:
        """ Return the item at the front of the linked list.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> first_item = linked_list.front
            >>> print(first_item)
            cat
        
        Returns:
            front (Any): the item stored in the head of the list
            
        Raises:
            IndexError: if the list is empty.
        
        """
        if self._head is None:
            raise IndexError('List has no values!')
        
        return self._head.item

    @property
    def back(self) -> Any:
        """ Return the item at the back of the linked list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> last_item = linked_list.back
            >>> print(last_item)    
            bird

        Returns:
            last (Any): the item stored in the tail of the list.
        
        Raises:
            IndexError: if the list is empty.
        """
        if self._tail is None:
            raise IndexError('List is empty.')

        return self._tail.item

    def clear(self) -> None:
        """ Clear the linked list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.clear()
            >>> print(linked_list)
            []
        
        Returns:
            None
        """
        self._head = None
        self._tail = None
        self._count = 0

    def extract(self, item: Any) -> None:
        """ Extract an item from the Linked List.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.extract('dog')
            >>> print(linked_list)
            ['cat', 'bird']

        Args:
            item (Any): the item to remove from the linked list.

        Returns:
            None

        Raises:
            KeyError: if the item is not found.
        """
        node = self._head
        while node is not None:
            if node.item == item:
                if node == self._head:
                    self._head = node.next
                    if self._head:
                        self._head.previous = None
                    else:
                        self._tail = None
                elif node == self._tail:
                    self._tail = node.previous
                    self._tail.next = None
                else:
                    node.previous.next = node.next
                    node.next.previous = node.previous
                self._count -= 1
                return None
            node = node.next
        
        raise KeyError("The item is not in the list.")


    @property
    def empty(self) -> bool:
        """ Property to determine whether the list is empty.
        
        Examples:
            >>> linked_list = LinkedList()
            >>> print(linked_list.empty)
            True
        
        Returns:
            bool: whether the list is empty.
        """
        if self._head is None:
            return True
        return False


    def pop_front(self) -> None:
        """ Remove the first item in the linked list.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.pop_front()
            >>> print(linked_list)
            ['dog', 'bird']
        
        Returns:
            None
        
        Raises:
            IndexError: if the list is empty.
            
        """
        
        if self._head is None:
            raise IndexError("Cannot pop from empty list!")

        self._head = self._head.next

        if self._head is None:
            self._tail = None

        self._count -= 1




    def pop_back(self) -> None:
        """ Remove the last item in the linked list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.pop_back()
            >>> print(linked_list)
            ['cat', 'dog']

        Returns:
            None
        
        Raises:
            IndexError: if the list is empty.
        """
        if self._count == 0:
            raise IndexError("The list is empty.")
        self._tail = self._tail.previous
        if self._tail != None:
            self._tail.next = None
        self._count -= 1
        return None

    def __contains__(self, item: Any) -> bool:
        """ Membership operator in.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print('dog' in linked_list)
            True
        
        Args:
            item (Any): the item to search for.
            
        Returns:
            bool: whether the linked list contains the item.
        """
        current = self._head
        while current is not None:
            if current.item == item:
                return True
            current = current.next
        
        return False


    def __eq__(self, other: object) -> bool:
        """ Equality operator ==.
        
        Examples:
            >>> linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list1 == linked_list2)
            True
        
        Args:
            other (object): the instance to compare self to.
            
        Returns:
            bool: whether the lists are equal (deep check).
        """
        if len(self) != len(other):
            return False
        found = False
        node = self._head
        other_node = other.head
        while not found:
            if node.item != other_node.item:
                return False
            else:
                if node != self._tail and other_node != other.tail:
                    node = node.next
                    other_node = other.node.next
                else:
                    return True
    def __ne__(self, other: object) -> bool:
        """ Non-Equality operator !=.
        
        Examples:
            >>> linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list1 != linked_list2)
            False
        
        Args:
            other (object): the instance to compare self to.
            
        Returns:
            bool: whether the lists are not equal (deep check).
        """
        if len(self) != len(other):
            return True

        return not self.__eq__(other)
    def __iter__(self) -> Any:
        """ Iterator operator.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> for item in linked_list:
            ...     print(item)
            cat
            dog
            bird
        
        Returns:
            Any: yields the item at ListNode.
        """
        current = self._head
        while current is not None:
            yield current.item
            current = current.next

    def __reversed__(self) -> Any:
        """ Reversed iterator operator.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> for item in reversed(linked_list):
            ...     print(item)
            bird
            dog
            cat
        
        Returns:
            Any: yields the item at ListNode.
        """
        
        current = self._tail
        while current is not None:
            yield current.item
            current = current.previous

    def __len__(self) -> int:
        """ len operator for getting length of the linked list.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> size = len(linked_list)
            >>> print(size)
            3
        
        Returns:
            int: the length of the LinkedList.
        """
        return self._count

    def __str__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list)
            ['cat', 'dog', 'bird']
            
        Returns:
            str: the string representation of the data and structure.
            
        """
        result = '['
        current = self._head
        while current is not None:
            result += str(current.item)
            if current.next is not None:
                result += ', '
            current = current.next
        
        result += ']'

        return result
    
    def __repr__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list)
            ['cat', 'dog', 'bird']
            
        Returns:
            str: the string representation of the data and structure.
        
        """
        result = "["
        current = self._head
        while current is not None:
            result += repr(current.item)
            if current.next is not None:
                result += ', '
            current = current.next
        
        result += ']'
    