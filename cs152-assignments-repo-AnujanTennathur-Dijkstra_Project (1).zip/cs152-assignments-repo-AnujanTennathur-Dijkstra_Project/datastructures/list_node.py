from __future__ import annotations
from typing import Any

class ListNode:
    """ ListNode - represents a node in a linked list
            Stipulations:
            1. Must adhere to the docstring requirements per method, including raising
               raising appropriate exceptions where indicated.
    """

    def __init__(self, item: Any, previous_node: ListNode | None = None, next_node: ListNode | None = None) -> None:
        """ Constructor - represents a node in a linked list.

            Examples:
                >>>node = ListNode('cat')  # Create a new node with 5 and no previous or next node.
                >>>node = ListNode('cat', None, None)  # Create a new node with 'cat' and no previous or next node.
                >>>print(node)
                cat

            Args:
                item (Any): the item (data) to store in the node
                previous_node (ListNode | None): the corresponding previous node of this node in the linked list
                next_node (ListNode | None): the corresponding next node of this node in the linked list
        """
        self._item = item
        self._previous = previous_node
        self._next = next_node

    @property
    def item(self) -> Any:
        """ Property getter for the item.
            
        Examples:
            >>>node = ListNode('cat')
            >>>item = node.item
            >>>print(item)
            cat
        
        Returns:
            Any: the item stored in the node.
        """
        return self._item

    @item.setter
    def item(self, item: Any) -> None:
        """ Property setter for the item.
        
        Examples:
            >>>node = ListNode('cat')
            >>>node.item = 'dog'
            >>>print(node)
            dog
        
        Args:
            item (Any): the item to store in the node.
            
        Returns:
            None
        """
        self._item = item

    @property
    def previous(self) -> ListNode | None:
        """ Property getter for the previous node.

        Examples:
            >>>node1 = ListNode('cat')
            >>>node2 = ListNode('dog', previous_node=node1)
            >>>print(node2.previous)
            cat
        
        Returns:
            ListNode | None: the previous node of the node.
        """      
        return self._previous

    @previous.setter
    def previous(self, previous_node: ListNode) -> None:
        """ Property setter for the previous node.

        Examples:
            >>>node1 = ListNode('cat')
            >>>node2 = ListNode('dog')
            >>>node2.previous = node1
            >>>print(node2.previous)
            cat

        Args:
            previous_node (ListNode): the node's previous_node instance.
        """
        self._previous = previous_node

    @property
    def next(self) -> ListNode | None:
        """ Property getter for the next node.
        
        Examples:
            >>>node1 = ListNode('cat')
            >>>node2 = ListNode('dog', next_node=node1)
            >>>print(node2.next)
            cat
        
        Returns:
            ListNode | None: the next node of the node.
        """
        return self._next

    @next.setter
    def next(self, next_node: ListNode) -> None:
        """ Property setter for the next node.
        
        Examples:
            >>>node1 = ListNode('cat')
            >>>node2 = ListNode('dog')
            >>>node2.next = node1
            >>>print(node2.next)
            cat
        
        Args:
            next_node (ListNode): the node's next_node instance.
        
        Returns:
            None
        """
        self._next = next_node

    def __eq__(self, other: object) -> bool:
        """ Equality operator ==.

            Examples:
                >>>node1 = ListNode('cat')
                >>>node2 = ListNode('cat')
                >>>node3 = ListNode('dog')
                >>>print(node1 == node2)
                True
                >>>print(node1 == node3)
                False

            Args:
                other (object): the instance to compare self to.
            
            Returns:
                bool: true if the nodes are equal (deep check). false if other is not a ListNode or they are not equal.
        """
        if isinstance(other, ListNode):
            return self._item == other._item
        return False

    def __str__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>>node = ListNode('cat')
            >>>print(node)
            cat
        
        Returns:
            str: the string representation of the data and structure.
        """
        return str(self._item)

    def __repr__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>>node = ListNode('cat')
            >>>print(node)
            cat
        
        Returns:
            str: the string representation of the data and structure.
        """
        return self.__str__()