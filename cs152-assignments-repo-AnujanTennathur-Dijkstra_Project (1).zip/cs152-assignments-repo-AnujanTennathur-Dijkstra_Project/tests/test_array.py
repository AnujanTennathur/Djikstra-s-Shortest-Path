# Collaborators: Aadem Isai

import pytest
from datastructures.array import Array

class TestArray:
    def test_set_operator_should_raise_index_error_for_negative_value(self):
        # Arrange
        test_array = Array(10)

        # Act & Assert
        with pytest.raises(IndexError):
            test_array[-1]

    def test_set_operator_should_raise_index_error_for_out_of_bounds(self):
        # Arrange
        test_array = Array(10)

        # Act & Assert
        with pytest.raises(IndexError):
            test_array[11]

    def test_set_operator_should_set_values(self):
        # Arrange
        test_array = Array(10)

        # Act
        for i in range(10):
            test_array[i] = i

        # Assert
        for i in range(10):
            assert test_array[i] == i

    def test_get_operator_should_get_values(self):
        # Arrange 
        test_array = Array(10)
        for i in range(10):
            test_array[i] = i

        # Act and Assert
        for i in range(10):
            assert test_array[i] == i
    
    def test_append_operator_should_return_none(self):
        # Arrange
        test_array = Array(1)
        
        # Act
        value = test_array.append(1)

        # Assert
        assert value == None

    def test_append_operator_should_add_values(self):
        # Arrange
        test_array = Array(1)

        # Act
        test_array.append(1)
        test_array.append(2)

        # Assert
        assert test_array[1] == 1
        assert test_array[2] == 2

    def test_resize_operator_should_raise_value_error(self):
        # Arrange
        test_array = Array(1)

        # Act and Assert
        with pytest.raises(ValueError):
            test_array.resize(-1)

    def test_resize_operator_should_make_array_smaller_cut_end_values(self):
        # Arrange
        test_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i
        test_array.resize(3)

        # Assert
        for i in range(len(test_array)):
            assert test_array[i] == i

    def test_resize_operator_should_make_array_smaller_check_len(self):
        # Arrange
        test_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i
        test_array.resize(3)

        # Assert
        assert len(test_array) == 3

    def test_resize_operator_should_make_array_bigger_with_value(self):
        # Arrange
        test_array = Array(3)

        # Act
        for i in range(3):
            test_array[i] = i
        test_array.resize(5, 1)

        # Assert
        for i in range(3):
            assert test_array[i] == i
        for i in range(3, 5):
            assert test_array[i] == 1

    def test_resize_operator_should_make_array_bigger_check_len(self):
        # Arrange
        test_array = Array(3)

        # Act
        for i in range(3):
            test_array[i] = i
        test_array.resize(5, 1)

        # Assert
        assert len(test_array) == 5

    def test_resize_operator_should_return_none(self):
        # Arrange
        test_array = Array(1)

        # Act
        value = test_array.resize(1)

        # Assert
        assert value == None

    def test_equality_operator_should_return_true(self):
        # Arrange
        test_array = Array(5)
        second_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i
            second_array[i] = i

        # Assert
        assert (test_array == second_array) == True

    def test_equality_operator_should_return_false(self):
        # Arrange
        test_array = Array(5)
        second_array = Array(6)

        # Act
        for i in range(5):
            test_array[i] = i
            second_array[i] = i

        # Assert
        assert (test_array == second_array) == False

    def test_non_equality_operator_should_return_false(self):
        # Arrange
        test_array = Array(5)
        second_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i
            second_array[i] = i

        # Assert
        assert (test_array != second_array) == False

    def test_non_equality_operator_should_return_true(self):
        # Arrange
        test_array = Array(5)
        second_array = Array(6)

        # Act
        for i in range(5):
            test_array[i] = i
            second_array[i] = i

        # Assert
        assert (test_array != second_array) == True

    def test_contains_method(self):
        # Arrange
        test_array = Array.from_list(['zero', 'one', 'two', 'three', 'four'])

        # Act & Assert
        assert 'three' in test_array
        assert 'five' not in test_array

    def test_clear_operator_should_return_none(self):
        # Arrange
        test_array = Array(5)

        # Act
        value = test_array.clear()

        # Assert
        assert value == None

    def test_clear_operator_should_clear_list(self):
        # Arrange
        test_array = Array(5)

        # Act
        test_array.clear()

        # Assert
        assert len(test_array) == 0

    def test_len_method_returns_logical_size_of_array(self):
        # Arrange
        test_array = Array(5)
    
        # Act
        result = len(test_array)

        # Assert
        assert result == 5

    def test_len_method_returns_zero_for_empty_array(self):
        # Arrange
        test_array = Array(0)
    
        # Act
        result = len(test_array)

        # Assert
        assert result == 0

    def test_does_not_contain_operator_should_return_true(self):
        # Arrange
        test_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i

        # Assert
        assert (6 not in test_array) == True

    def test_does_not_contain_operator_should_return_false(self):
        # Arrange
        test_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i

        # Assert
        assert (3 not in test_array) == False
    def test_does_not_contain_method_returns_true_for_non_existing_item(self):
        # Arrange
        test_array = Array.from_list([1, 2, 3])

        # Act
        result = 4 not in test_array

        # Assert
        assert result is True

    def test_delete_item_operator_should_delete_item_check_values(self):
        # Arrange
        test_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i
        del test_array[3]

        # Assert
        for i in range(4):
            if i == 0 or i == 1 or i == 2:
                assert test_array[i] == i
            else:
                assert test_array[i] == i + 1

    def test_delete_item_operator_should_delete_item_check_len(self):
        # Arrange
        test_array = Array(5)

        # Act
        for i in range(5):
            test_array[i] = i
        del test_array[3]

        # Assert
        assert len(test_array) == 4

    def test_str_method_returns_string_representation_of_array(self):
        # Arrange
        test_array = Array(3)
        test_array[0] = "zero"
        test_array[1] = "one"
        test_array[2] = "two"

        # Act and Assert
        assert str(test_array) == "[zero, one, two]"


    def test_repr_operator_should_make_string(self):
        # Arrange
        test_array = Array(3)
        test_array[0] = "zero"
        test_array[1] = "one"
        test_array[2] = "two"

        # Act and Assert
        assert repr(test_array) == "[zero, one, two]"

    