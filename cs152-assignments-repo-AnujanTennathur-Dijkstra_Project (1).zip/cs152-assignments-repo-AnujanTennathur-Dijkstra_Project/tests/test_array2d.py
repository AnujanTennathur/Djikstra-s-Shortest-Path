# This is a file you can copy/paste to create a new test file.
# Just make sure the new name starts with test_ and ends with .py.

# import data structures like this:
# from datastructures.array import Array

# Collaborator: Aadem Isai

import pytest

from datastructures.array2d import Array2D


class TestArray2D:

    def test_this(self):
        assert True
        

    @pytest.fixture
    def numerical_array2d(self) -> Array2D:
        array2d = Array2D(3, 4)
        row_len, col_len = array2d.dimensions

        i = 0
        for row in range(row_len):
            for col in range(col_len):
                array2d[row][col] = i
                i += 1
        return array2d
    
    @pytest.fixture
    def numerical_array2d_from_list(self) -> Array2D:
        return Array2D.from_list([[0, 1, 2, 3], 
                                  [4, 5, 6, 7], 
                                  [8, 9, 10, 11]])
    

    def test_index_operator_of_arrays2D(self, numerical_array2d: Array2D):
        rows, columns = numerical_array2d.dimensions # 3 x 4

        i = 0
        for row in range(rows):
            for col in range(columns):
                assert numerical_array2d[row][col] == i
                i += 1
    
    def test_resize_columns_larger_should_pad_data_with_defaults(self, numerical_array2d: Array2D):
        rows, columns = numerical_array2d.dimensions # 3 x 4
        # [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11]]
        expected = 66

        numerical_array2d.resize_columns(6, 0) # 3 x 6
        #[[0, 1, 2, 3, 0, 0], [4, 5, 6, 7, 0, 0], [8, 9, 10, 11, 0, 0]

        actual = 0

        rows, columns = numerical_array2d.dimensions
        
        for row in range(rows):
            for col in range(columns):
                actual += numerical_array2d[row][col]

        assert expected == actual

    def test_resize_columns_smaller_should_truncate_the_data (self, numerical_array2d: Array2D):
        rows, columns = numerical_array2d.dimensions # 3 x 4
            # [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11]]
        expected = 27

        numerical_array2d.resize_columns(2, 0) # 3 x 2
        # [[0, 1], [4, 5], [8, 9]]

        actual = 0

        rows, columns = numerical_array2d.dimensions

        for row in range(rows):
            for col in range(columns):
                actual += numerical_array2d[row][col]

        assert expected == actual

    def test_resize_rows_larger_should_resize_the_row_len_and_pad_the_data_with_the_specified_default_value(self, numerical_array2d: Array2D):
        rows, columns = numerical_array2d.dimensions #3 x 4

        expected = 0

        for row in range(rows):
            for col in range(columns):
                expected += numerical_array2d[row][col] 

        numerical_array2d.resize_rows(4, 0) # 4 x 4

        actual = 0

        rows, columns = numerical_array2d.dimensions

        for row in range(rows):
            for col in range(columns):
                actual += numerical_array2d[row][col]

        assert expected == actual

    def test_equality_operator_for_two_equal_two_dimensional_arrays_returning_true(self, numerical_array2d: Array2D):
        array2d_one = Array2D(2, 3) # 2 by 3 dimension array
        array2d_two = Array2D(2, 3) # same as array above

        assert array2d_one == array2d_two # Should equal each other :)

    def test_equality_operator_for_two_not_equal_two_dimensional_arrays_returning_true(self, numerical_array2d: Array2D):
        array2d_one = Array2D(2,3) # 2 by 3 dimension array
        array2d_two = Array2D(3,4) # 3 by 4 dimension array

        array2d_three = Array2D(2, 4) # 2 by 4 dimension array

        assert array2d_one != array2d_two #These assertions should not equal each other :)
        assert array2d_one != array2d_three 
        assert array2d_two != array2d_three

    def test_item_should_be_in_the_given_array_aka_contains_function(self, numerical_array2d: Array2D):
        array2d = Array2D(rows=2, columns=3)

        array2d[0][0] = 3
        assert 3 in array2d

    def test_item_is_not_in_the_given_array_aka_also_in_contains_function(self, numerical_array2d: Array2D):
        array2d = Array2D(rows = 2, columns = 3)

        assert 3 not in array2d

    def test_items_that_should_clear_to_be_none_in_each_value(self, numerical_array2d: Array2D):
        array2d = Array2D(rows=2, columns=3)
        array2d[0][0] = 1
        array2d[0][1] = 2
        array2d[1][0] = 3

        array2d.clear()

        for i in range(array2d.dimensions[0]):
            for j in range(array2d.dimensions[1]):
                assert array2d[i][j] == None
    
    def test_str_method(self):
        # Create an Array2D instance with some initial values
        array2d = Array2D(rows=2, columns=3)
        array2d[0][0] = 1
        array2d[0][1] = 2
        array2d[1][0] = 3

        # Define the expected string representation
        expected_str = "[[1, 2, None], [3, None, None]]"

        # Check that the __str__ method returns the expected string representation
        assert str(array2d) == expected_str

    def test_repr_method(self):
        array2d = Array2D(rows = 2, columns = 3)
        array2d[0][0] = 1
        array2d[0][1] = 2
        array2d[1][0] = 3

        expected_repr = "[[1, 2, None], [3, None, None]]"

        assert repr(array2d) == expected_repr

    def test_constructor_negative_rows(self):
        with pytest.raises(ValueError):
            Array2D(rows=-1, columns=3)

    def test_constructor_negative_columns(self, numerical_array2d: Array2D):
        with pytest.raises(ValueError):
            Array2D(rows=2, columns=-1)


    def test_clear_method(self, numerical_array2d: Array2D):
        array2d = Array2D(rows=2, columns=3)
        array2d.clear()
        
        assert array2d.dimensions == (2, 3)
        
        for i in range(2):
            for j in range(3):
                assert array2d[i][j] == None
