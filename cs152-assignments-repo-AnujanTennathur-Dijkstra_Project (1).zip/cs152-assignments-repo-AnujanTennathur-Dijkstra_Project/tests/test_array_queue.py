# Collaborator: Jenna

import pytest
from datastructures.array_queue import ArrayQueue

class TestArrayQueue: 

    @pytest.fixture
    def setup_queue(self):
        queue = ArrayQueue(5)

        for i in range(3):
            queue.enqueue(i)

        return queue

    def test_enqueue_item_should_enqueue_3(self, setup_queue):
        # Act
        setup_queue.enqueue(3)

        # Assert
        assert 4 == len(setup_queue)

    def test_enqueue_should_contain_the_sum_of_6(self, setup_queue):
        
        sum = 0
        expected = 6
        
        # Act
        setup_queue.enqueue(3)

        while not setup_queue.empty:
            sum += setup_queue.dequeue()

        # Assert
        assert expected == sum

    def test_dequeue_item_should_dequeue_last_item(self, setup_queue):
    
        sum = 0
        expected = 2

        # Act
        setup_queue.dequeue()
        setup_queue.dequeue()

        while not setup_queue.empty:
            sum += setup_queue.dequeue()

        # Assert
        assert expected == sum

    def test_dequeue_item_should_return_the_item_dequeued(self, setup_queue):
        # Act
        item = setup_queue.dequeue()

        # Assert
        assert 0 == item

    def test_clear_queue_should_empty_queue(self, setup_queue):
        # Act
        setup_queue.clear()

        # Assert
        assert setup_queue.empty

    def test_clear_queue_should_be_len_0(self, setup_queue):
        # Act
        setup_queue.clear()

        # Assert
        assert 0 == len(setup_queue)

    def test_front_property_should_return_0(self, setup_queue):
        # Assert
        assert 0 == setup_queue.front

    def test_front_property_should_raise_index_error(self):
        # Arrange and Act
        queue = ArrayQueue(5)

        # Assert
        with pytest.raises(IndexError):
            queue.front

    def test_full_property_should_return_true(self, setup_queue):
        # Arrange and Act
        setup_queue.enqueue(3)
        setup_queue.enqueue(4)

        # Assert
        assert setup_queue.full

    def test_full_property_should_return_false(self, setup_queue):
        # Assert
        assert not setup_queue.full

    def test_full_property_should_be_correct_size(self, setup_queue):
        # Act and Arrange
        setup_queue.enqueue(3)
        setup_queue.enqueue(4)

        # Assert
        assert 5 == len(setup_queue)

    def test_queue_is_empty_when_there_no_items(self):
        # Arrange
        queue = ArrayQueue(5)

        # Act
        is_empty =queue.empty

        # Assert
        assert is_empty

    def test_empty_property_should_return_false(self, setup_queue):
        # Assert
        assert not setup_queue.empty

    def test_size_when_queue_is_empty_should_be_zero(self):
        # Arrange
        queue = ArrayQueue(5)

        # Act
        size = len(queue)

        # Assert
        assert 0 == size

    def test_equality_operator_should_return_true(self, setup_queue):
        # Arrange
        test_queue = ArrayQueue(5)

        # Act
        for i in range(3):
            test_queue.enqueue(i)

        # Assert
        assert test_queue == setup_queue

    def test_equality_operator_should_return_false(self, setup_queue):
        # Arrange and Act
        test_queue = ArrayQueue(5)

        # Assert
        assert not test_queue == setup_queue

    def test_equality_operator_with_list_should_return_false(self, setup_queue):
        # Arrange and Act
        list = [0, 1, 2]

        # Assert
        assert not list == setup_queue

    def test_non_equality_operator_should_return_false(self, setup_queue):
        # Arrange
        test_queue = ArrayQueue(5)

        # Act
        for i in range(3):
            test_queue.enqueue(i)

        # Assert
        assert (test_queue != setup_queue) == False

    def test_non_equality_operator_should_return_true(self, setup_queue):
        # Arrange and Act
        test_queue = ArrayQueue(5)

        # Assert
        assert test_queue != setup_queue

    def test_non_equality_operator_with_list_should_return_true(self, setup_queue):
        # Arrange and Act
        list = [0, 1, 2]

        # Assert
        assert list != setup_queue

    def test_len_queue_should_return_correct_len(self, setup_queue):
        # Assert
        assert 3 == len(setup_queue)

    def test_str_queue_should_return_string_with_items(self, setup_queue):
        # Arrange and Act
        message = "[0, 1, 2]"

        # Assert
        assert message == str(setup_queue)

    def test_repr_queue_should_return_string_with_items(self, setup_queue):
        # Arrange and Act
        message = "[0, 1, 2]"

        # Assert
        assert message == repr(setup_queue)

