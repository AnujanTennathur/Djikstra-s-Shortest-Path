# Collaborator: Jenna 

import pytest

from datastructures.array_stack import ArrayStack


class TestArrayStack:
    @pytest.fixture
    def setup_stack(self):
        stack = ArrayStack(5)

        for i in range(3):
            stack.push(i)

        return stack
    
    def test_push_item_should_push_3(self, setup_stack):
        # Act
        setup_stack.push(3)

        # Assert
        assert 4 == len(setup_stack)

    def test_stack_should_contain_the_sum_of_6(self, setup_stack):
        
        sum = 0
        expected = 6
        
        # Act
        setup_stack.push(3)

        while not setup_stack.empty:
            sum += setup_stack.pop()

        # Assert
        assert expected == sum

    def test_pop_item_should_pop_last_item(self, setup_stack):
    
        sum = 0
        expected = 1

        # Act
        setup_stack.pop()

        while not setup_stack.empty:
            sum += setup_stack.pop()

        # Assert
        assert expected == sum

    def test_pop_item_should_return_the_item_popped(self, setup_stack):
        # Act
        item = setup_stack.pop()

        # Assert
        assert 2 == item

    def test_clear_stack_should_empty_stack(self, setup_stack):
        # Act
        setup_stack.clear()

        # Assert
        assert setup_stack.empty

    def test_clear_stack_should_be_len_0(self, setup_stack):
        # Act
        setup_stack.clear()

        # Assert
        assert 0 == len(setup_stack)

    def test_top_property_should_return_2(self, setup_stack):
        # Assert
        assert 2 == setup_stack.top

    def test_top_property_should_raise_index_error(self):
        # Arrange and Act
        stack = ArrayStack(5)

        # Assert
        with pytest.raises(IndexError):
            stack.top

    def test_full_property_should_return_true(self, setup_stack):
        # Arrange and Act
        setup_stack.push(3)
        setup_stack.push(4)

        # Assert
        assert setup_stack.full

    def test_full_property_should_return_false(self, setup_stack):
        # Assert
        assert not setup_stack.full

    def test_full_property_should_be_correct_size(self, setup_stack):
        # Act and Arrange
        setup_stack.push(3)
        setup_stack.push(4)

        # Assert
        assert 5 == len(setup_stack)

    def test_stack_is_empty_when_there_no_items(self):
        # Arrange
        stack = ArrayStack(5)

        # Act
        is_empty = stack.empty

        # Assert
        assert is_empty

    def test_empty_property_should_return_false(self, setup_stack):
        # Assert
        assert not setup_stack.empty

    def test_size_when_stack_is_empty_should_be_zero(self):
        # Arrange
        stack = ArrayStack(5)

        # Act
        size = len(stack)

        # Assert
        assert 0 == size

    def test_equality_operator_should_return_true(self, setup_stack):
        # Arrange
        test_stack = ArrayStack(5)

        # Act
        for i in range(3):
            test_stack.push(i)

        # Assert
        assert test_stack == setup_stack

    def test_equality_operator_should_return_false(self, setup_stack):
        # Arrange and Act
        test_stack = ArrayStack(5)

        # Assert
        assert not test_stack == setup_stack

    def test_equality_operator_with_list_should_return_false(self, setup_stack):
        # Arrange and Act
        list = [0, 1, 2]

        # Assert
        assert not list == setup_stack

    def test_non_equality_operator_should_return_false(self, setup_stack):
        # Arrange
        test_stack = ArrayStack(5)

        # Act
        for i in range(3):
            test_stack.push(i)

        # Assert
        assert (test_stack != setup_stack) == False

    def test_non_equality_operator_should_return_true(self, setup_stack):
        # Arrange and Act
        test_stack = ArrayStack(5)

        # Assert
        assert test_stack != setup_stack

    def test_non_equality_operator_with_list_should_return_true(self, setup_stack):
        # Arrange and Act
        list = [0, 1, 2]

        # Assert
        assert list != setup_stack

    def test_len_stack_should_return_correct_len(self, setup_stack):
        # Assert
        assert 3 == len(setup_stack)

    def test_str_stack_should_return_string_with_items(self, setup_stack):
        # Arrange and Act
        message = "[0, 1, 2]"

        # Assert
        assert message == str(setup_stack)

    def test_repr_stack_should_return_string_with_items(self, setup_stack):
        # Arrange and Act
        message = "[0, 1, 2]"

        # Assert
        assert message == repr(setup_stack)