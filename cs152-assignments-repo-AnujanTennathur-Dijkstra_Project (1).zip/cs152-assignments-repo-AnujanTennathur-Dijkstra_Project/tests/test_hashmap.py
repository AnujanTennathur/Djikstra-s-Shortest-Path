from collections.abc import Iterable
from typing import Any
import pytest
from car import Car, Color, Make, Model
from datastructures import hash_map
from datastructures.hash_map import HashMap


CAPACITY = 23
car1 = Car('123', Color.RED, Make.TOYOTA, Model.COROLLA)
car2 = Car('456', Color.BLUE, Make.HONDA, Model.CIVIC)
car3 = Car('789', Color.GREEN, Make.TOYOTA, Model.FOCUS)

@pytest.fixture
def simple_hashmap() -> HashMap: 
    hashmap = HashMap(CAPACITY)

    for i in range(10): 
        hashmap[i] = i
    
    return hashmap

@pytest.fixture
def complex_hashmap() -> hash_map: 
    hashmap = HashMap(CAPACITY)

    hashmap[car1.vin] = car1
    hashmap[car2.vin] = car2
    hashmap[car3.vin] = car3

    return hashmap

def default_hash_function(key: Any, capacity: int) -> int:
    """ Default hash function for the HashMap classl, supports scalar and iterable keys.
        
        Args:
            key (Any): The key to hash.
            capacity (int): The capacity of the hash map.
            
        Returns:
            int: The hash of the key for a container containing the given capacity.
    """
    if isinstance(key, Iterable):
        return sum([hash(val) for val in key]) % capacity
    
    return hash(key) % capacity

def test_init_should_create_hashmap_with_len_10(): 
    hashmap = HashMap()
    assert 0 == len(hashmap)

def test_init_should_create_hashmap_with_capacity_23(): 
    hashmap = HashMap()
    assert 7 == hashmap.capacity

def test_setitem_should_insert_value(simple_hashmap): 
    for i in range(10): 
        assert i == simple_hashmap[i]

def test_key_that_doesnt_exist_should_raise_exception_getitem(simple_hashmap): 
    with pytest.raises(KeyError): 
        simple_hashmap[11]

def test_complex_hashmap_should_contain_cars(complex_hashmap):
    assert car1 == complex_hashmap[car1.vin]
    assert car2 == complex_hashmap[car2.vin]
    assert car3 == complex_hashmap[car3.vin]

def test_complex_hashmap_should_raise_exception_for_nonexistent_vin(complex_hashmap):
    with pytest.raises(KeyError):
        complex_hashmap['nonexistent_vin']

def test_del_item_should_delete_item_in_middle_of_hashmap(simple_hashmap):
        del simple_hashmap[4]

        sum = 0
        for key in simple_hashmap:
            sum += simple_hashmap[key]
        
        assert 41 == sum

def test_contains_should_return_true_for_existing_key(simple_hashmap):
    assert 5 in simple_hashmap

def test_contains_should_return_false_for_nonexistent_key(simple_hashmap):
    assert 11 not in simple_hashmap

def test_len_should_return_number_of_items_in_hashmap(simple_hashmap):
    assert len(simple_hashmap) == 10

def test_iter_should_iterate_over_keys_in_hashmap(simple_hashmap):
    for key in simple_hashmap:
        assert key in range(10)

def test_resize_and_rehash_should_increase_capacity_and_preserve_items(simple_hashmap):
    old_capacity = simple_hashmap.capacity
    new_capacity = old_capacity * 2
    simple_hashmap.resize_and_rehash(new_capacity, default_hash_function)
    assert simple_hashmap.capacity == new_capacity
    for i in range(10):
        assert i == simple_hashmap[i]

def test_from_dictionary_should_create_hashmap_from_dict():
    dictionary = {i: i for i in range(10)}
    hashmap = HashMap.from_dictionary(dictionary)
    for i in range(10):
        assert i == hashmap[i]

def test_capacity_should_return_hashmap_capacity(simple_hashmap):
    assert simple_hashmap.capacity == CAPACITY

def test_eq_function_should_return_true(simple_hashmap):
        other_hashmap = HashMap(CAPACITY)
        for i in range(10):
            other_hashmap[i] = i

        assert other_hashmap == simple_hashmap

def test_eq_function_should_return_false(simple_hashmap):
    other_hashmap = HashMap(CAPACITY)

    assert not other_hashmap == simple_hashmap

def test_eq_function_should_also_return_false(simple_hashmap):
    other_hashmap = [1, 2, 3]

    assert not other_hashmap == simple_hashmap


def test_ne_should_return_true_for_different_hashmaps():
    hashmap1 = HashMap.from_dictionary({i: i for i in range(10)})
    hashmap2 = HashMap.from_dictionary({i: i+1 for i in range(10)})
    assert hashmap1 != hashmap2

def test_load_factor_threshold_should_be_60_percent(simple_hashmap):
        assert 0.6 == simple_hashmap.load_factor_threshold

def test_load_factor_and_threshold_should_not_resize(simple_hashmap):
    for i in range(3):
        simple_hashmap[i + 11] = i + 11

    assert 23 == simple_hashmap.capacity

def test_load_factor_and_threshold_should_resize_to_29(simple_hashmap):
    for i in range(5):
        simple_hashmap[i + 11] = i + 11

    assert 29 == simple_hashmap.capacity

def test_clear_should_empty_hashmap(simple_hashmap):
    simple_hashmap.clear()
    assert len(simple_hashmap) == 0

def test_keys_should_return_all_keys(simple_hashmap):
    keys = simple_hashmap.keys()
    for i in range(10):
        assert i in keys

def test_values_should_return_all_values(simple_hashmap):
    values = simple_hashmap.values()
    for i in range(10):
        assert i in values

def test_items_should_return_all_key_value_pairs(simple_hashmap):
    items = simple_hashmap.items()
    for i in range(10):
        assert (i, i) in items

def test_str_should_return_string_like_dictionary(simple_hashmap):
    message = "{0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}"

    assert str(simple_hashmap) == message

def test_repr_should_return_string_like_dictionary(simple_hashmap):
    message = "{0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}"

    assert str(simple_hashmap) == message