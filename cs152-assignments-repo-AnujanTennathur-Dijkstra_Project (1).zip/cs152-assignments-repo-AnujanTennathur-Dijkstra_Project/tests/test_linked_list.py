# This is a file you can copy/paste to create a new test file.
# Just make sure the new name starts with test_ and ends with .py.

# import data structures like this:
# from datastructures.array import Array
from ctypes import Array
import pytest
from datastructures.linked_list import LinkedList
from datastructures.list_node import ListNode

class Test_Linked_List:

    def test_from_list_raise_Type_Error(self):
        py_list = 10
        with pytest.raises(TypeError):
            LinkedList.from_list(py_list)
    
    def test_from_list_single_element(self): 
        py_list = ['cat']
        linked_list = LinkedList.from_list(py_list)
        assert linked_list._head._item == 'cat'
        assert linked_list._head._next == None
    
    def test_from_list_multiple_elements(self): 
        py_list = ['cat', 'dog', 'bird']
        linked_list = LinkedList.from_list(py_list)
        assert linked_list._head._item == 'cat'
        assert linked_list._tail._item == 'bird'
    
    def test_append_append_to_empty_list(self): 
        linked_list = LinkedList()
        linked_list.append('cat')
        assert linked_list._head._item == 'cat'
        assert linked_list._tail._item == 'cat'
    
    def test_append_append_to_list_with_elements(self): 
        linked_list = LinkedList()
        linked_list.append('cat')
        linked_list.append('dog')
        linked_list.append('bird')
        assert linked_list._head._item == 'cat'
        assert linked_list._tail._item == 'bird'
    
    def test_prepend_prepend_to_empty_list(self):
        linked_list = LinkedList()
        linked_list.prepend('cat')
        assert linked_list._head._item == 'cat'
        assert linked_list._tail._item == 'cat'
    
    def test_prepend_prepend_to_list_with_elements(self):
        linked_list = LinkedList()
        linked_list.append('cat')
        linked_list.append('dog')
        linked_list.prepend('bird')
        assert linked_list._head._item == 'bird'
        assert linked_list._tail._item == 'dog'

    def test_empty_empty_list(self):
        linked_list = LinkedList()
        assert linked_list.empty is True
    
    def test_empty_non_empty_list(self): 
        linked_list = LinkedList()
        linked_list.append("fish")
        assert linked_list.empty is False
    
    def test_pop_front_empty_list(self): 
        linked_list = LinkedList()
        with pytest.raises(IndexError): 
            linked_list.pop_front()
    
    def test_pop_front_list_with_elements(self):
        linked_list = LinkedList.from_list(['basketball', 'soccer', 'football'])
        linked_list.pop_front()
        assert linked_list.empty is False
        assert linked_list._head._item == 'soccer'
        assert linked_list._tail._item == 'football'
    
    def test_pop_back_empty_list(self):
        linked_list = LinkedList()
        with pytest.raises(IndexError):
            linked_list.pop_back()
    
    def test_pop_back_list_with_elements(self): 
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        linked_list.pop_back()
        assert linked_list.empty is False
        assert linked_list._head._item == 'cat'
        assert linked_list._tail._item == 'dog'
    
    def test_contains_item_not_in_list(self): 
        linked_list = LinkedList()
        assert "walrus" not in linked_list
    
    def test_contains_item_in_list(self): 
        linked_list = LinkedList.from_list(["walrus", "donkey", "seal"])
        assert "walrus" in linked_list
    
    def test_eq_input_not_linked_list(self): 
        py_list = 10
        with pytest.raises(TypeError):
            LinkedList.__eq__(py_list)

    def test_eq_lists_are_equal(self):
        linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
        linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
        assert linked_list1 == linked_list2
    
    def test_eq_operator_should_return_false(self):
        linked_list1 = LinkedList.from_list(['cat', 'cat', 'bird'])
        linked_list2 = LinkedList.from_list(['cat', 'dog', 'fish'])
        assert linked_list1 != linked_list2
    
    def test_ne(self):
        linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
        linked_list2 = LinkedList.from_list(['cat', 'dog', 'fish'])
        assert linked_list1 != linked_list2

    def test_extract_item_not_in_Linked_List(self): 
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        with pytest.raises(KeyError):
            linked_list.extract('fish')
    
    def test_extract_item_found(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        linked_list.extract('dog')
        assert 'dog' not in linked_list
    
    def test_insert_before_specified_item_not_in_list(self): 
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        with pytest.raises(KeyError): 
            linked_list.insert_before('walrus', 'dog')
    
    def test_insert_before_item_in_list(self): 
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        linked_list.insert_before('cat', 'walrus')
        assert linked_list._head._item== 'walrus'

    def test_insert_after_specifed_item_not_in_list(self): 
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        with pytest.raises(KeyError): 
            linked_list.insert_before('walrus', 'dog')
    
    def test_insert_after_item_in_list(self): 
        linked_list = LinkedList.from_list(['cat'])
        linked_list.insert_after('cat', 'walrus')
        assert linked_list._tail._item== 'walrus'
    
    def test_head(self): 
        linked_list = LinkedList.from_list(['cat', 'dog'])
        assert linked_list.head._item == 'cat'
    
    def test_tail(self): 
        linked_list = LinkedList.from_list(['cat', 'dog'])
        assert linked_list.tail._item == 'dog'
    
    def test_front(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        first_item = linked_list.front
        assert first_item == 'cat'
    
    def test_back(self): 
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        back_item = linked_list.back
        assert back_item == 'bird'
    
    def test_clear(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        linked_list.clear()
        assert linked_list.empty is True
    
    def test_iter(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        items = []
        for item in linked_list:
            items.append(item)
        assert items == ['cat', 'dog', 'bird']
    
    def test_reversed(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        items = []
        for item in reversed(linked_list):
            items.append(item)
        assert items == ['bird', 'dog', 'cat']

    def test_len(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        assert len(linked_list) == 3
    
    def test_str_operator_should_print_elements(self):
        linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
        assert str(linked_list) == "[cat, dog, bird]"

        
   


    





